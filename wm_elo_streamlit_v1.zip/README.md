# FIFA WM Elo Tracker

Leistungsschonende Streamlit-Version.

Startdatei für Streamlit Cloud: `app.py`
